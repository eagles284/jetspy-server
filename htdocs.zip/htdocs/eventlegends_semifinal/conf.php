<?php 

// MySQL Credentals
$dbhost = "127.0.0.1";
$dbun = "root";
$dbpw = "";
$dbname = "eagles30_dbdata";

$conn = mysqli_connect($dbhost, $dbun, $dbpw, $dbname);

$dataPerPage = 30;

//For directories related
$rootdir = "/panel/";

$style_css = "/panel/css/style.css";
$favicon = "/panel/res/favicon.png";

$signin_css = "/panel/css/signin.css";
$bootstrap_min_css = "/panel/css/bootstrap.min.css";
 ?>