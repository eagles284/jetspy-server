<?php 

//MySQL Credentals
$mysql_host = "localhost:3306";
$mysql_username = "eagles30_dbdata";
$mysql_password = "Riyco321";
$mysql_name = "eagles30_dbdata";

// MySQL Credentals
$dbhost = "localhost:3306";
$dbun = "eagles30_dbdata";
$dbpw = "Riyco321";
$dbname = "eagles30_dbdata";

$conn = mysqli_connect($dbhost, $dbun, $dbpw, $dbname);

//For directories related
$rootdir = "/panel/";

$style_css = "/panel/css/style.css";
$favicon = "/panel/res/favicon.png";

$signin_css = "/panel/css/signin.css";
$bootstrap_min_css = "/panel/css/bootstrap.min.css";

 ?>