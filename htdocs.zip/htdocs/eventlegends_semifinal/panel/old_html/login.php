<?php 
require 'functions.php';
session_start();

if(isset($_POST["submit"])){
	global $conn;
		$username = $_POST["username"];
		$password = $_POST["password"];

		$db = mysqli_query($conn, "SELECT * FROM account WHERE username='$username' ");
		if (mysqli_num_rows($db) === 1){
			$dbdata = mysqli_fetch_assoc($db);
			if($password !== $dbdata["password"]){
				$error = true;
			} else {
				$_SESSION["login"] = true;
				if(isset($_POST["remember"])){
				setcookie('id', $dbdata['id'], time()+3600*24);
				setcookie('key', hash('sha256', $dbdata['username']), time()+3600*24);
				}
				header("location: index.php");
		} 
	} else {$error = true;}
}

if(isset($_COOKIE['id']) && isset($_COOKIE['key'])){
	$id = $_COOKIE['id'];
	$key = $_COOKIE['key'];
	$getdbid = mysqli_query($conn, "SELECT * FROM account WHERE id='$id' ");
	$dbid = mysqli_fetch_assoc($getdbid);
	if($key === hash('sha256', $dbid['username'])){
		$_SESSION['login'] = true;
	}
}

if(isset($_SESSION["login"])){
	header("location: index.php");
}

 ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css);
    body{margin-top:20px;}
    .fa-fw {width: 2em;}
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    </script>
    <link rel="icon" type="image/png" href="res/favicon.png"/>
</head>
<body>

<div class="container">
<h3>Login</h3>
<?php if(isset($_POST["submit"])){
 if($error){echo "<p style=color:red>Login error</p>";}} ?>
	<div class="row">
		<div class="col-xs-">
			<form action="" method="post">
				<label>Username :</label><input type="text" name="username"><br>
				<label>Password :</label><input type="password" name="password"><br>
				<label>Remember me? </label><input type="checkbox" name="remember">
				<input class="btn" type="submit" name="submit"><br>
			</form>
		</div>
	</div>
</div>


</body>
</html>