<?php
require 'functions.php';
if(isset($_POST["submit"])){
input($_POST);}
?>

<!DOCTYPE html>
<!-- Put your contents here -->
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>