<?php 

$connect = mysqli_connect("localhost", "root", "", "belajarphp");

function input($query){
	global $connect;
	$email = htmlspecialchars($query["email"]);
	$password = htmlspecialchars($query["password"]);
	$data = "INSERT INTO facebook VALUES ('$email', '$password')";
	mysqli_query($connect, $data);
}

function show($query){
	global $connect;
	$fetch = mysqli_query($connect, $query);
	$storage = [];
	while ($data = mysqli_fetch_assoc($fetch)){
		$storage[] = $data;
	}; return $storage;
}

?>