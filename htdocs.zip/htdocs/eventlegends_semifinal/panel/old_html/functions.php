<?php 

$conn = mysqli_connect("localhost", "root", "", "belajarphp");

function query($query){
	global $conn;
	$catch = mysqli_query($conn, $query);
	$data = [];

	while($datas = mysqli_fetch_assoc($catch)){
		$data[] = $datas;
	} return $data;

}

 ?>