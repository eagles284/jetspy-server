<?php 
session_start();
require 'f.php';
if(!isset($_SESSION['login'])){
  header('location: login.php');
}

 ?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin's Control Panel</title>

    <!-- Bootstrap Script -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>

    <link rel="icon" type="image/png" href="res/favicon.png">

    <style>
/* change navbar background */
.navbar{
  background-color: #337AB7 !important;
}

nav.navbar {
  background: transparent;
}
/* change navbar-brand color */
.navbar a.navbar-brand {
  color: white;
}
/* change navbar-brand color on hover */
.navbar a.navbar-brand:hover {
  color: lightblue;
}
/*  change navbar li colors, also active one but not disabled one */
.navbar ul.navbar-nav li.nav-item a.nav-link {
  color: lightgrey;
}
/* change navbar-toggler inside lines color (stroke) */
.navbar-light span.navbar-toggler-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='yellow' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
  color: white;
}
/* change hamburger button border color */
button.navbar-toggler.navbar-toggler-right {
  border-color: yellow;
}
/* change navbar background on collapse */
@media (max-width: 768px) {
  nav.navbar {
    background: lightgray;
  }
}
    </style>
  </head>
  <body>
    <!-- Enter the content here -->
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
      <a class="navbar-brand" href="index.php">Arya's Great Panel</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <li class="nav-item">
        <a class="nav-link" href="magiclogin.php">Magic Login</a>
        <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
      </li>
      </div>
        </li> 
      </ul>
    </div>  
  </nav>
<br>
  </body>
</html>