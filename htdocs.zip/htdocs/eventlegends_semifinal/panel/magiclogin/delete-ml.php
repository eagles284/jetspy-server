<?php 
require __DIR__."/../f.php";

$id = $_GET['id'];
$delete = $_GET['del'];
$mldata = query("SELECT * FROM mldata WHERE id='$id'");

if($delete=="yes"){
	mysqli_query($conn, "DELETE from mldata WHERE id='$id'");
	header("location: saved-ml.php");
}
?>

 <!DOCTYPE html>
 <html>
 	<head>
    <meta charset="utf-8">
    <title>Admin Control Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css);
    body{margin-top:20px;}
    .fa-fw {width: 2em;}
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
    <link rel="stylesheet" type="text/css" href="/panel/css/style.css">
    <link rel="icon" type="image/png" href="/panel/res/favicon.png"/>
    <style type="text/css">
#outer
{
    width:100%;
    text-align: right;
}
.inner
{
    display: inline-block;
}
    </style>
</head>
<div class="container">
 <body>
 <b>Are you sure want to delete:</b><br><br>
 <p><?=$mldata['email']?></p>
 <p><?=$mldata['password']?></p>
 <p><?=$mldata['des']?></p>
 <a href="/panel/magiclogin/saved-ml.php">No</a> / <a href="delete-ml.php?id=<?=$id?>&del=yes">Yes</a>
 </div>
 </body>

 </html>
