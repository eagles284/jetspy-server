<?php 
require __DIR__."/../../conf.php";
 ?>