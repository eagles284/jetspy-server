<?php 
require __DIR__ . '/../conf.php';
$conn = mysqli_connect($dbhost, $dbun, $dbpw, $dbname);

function dbquery($query){
	global $conn;
	$fetch = mysqli_query($conn, $query);
	$datas = [];

	while($data = mysqli_fetch_assoc($fetch)){
		$datas[] = $data;
	} return $datas;
}

function query($query){
	global $conn;
	$fetch = mysqli_query($conn, $query);
	$data = mysqli_fetch_assoc($fetch);
	return $data;
}


 ?>