<?php

$jawaban = $_POST['jawaban'];

$data = "\n $jawaban";

file_put_contents("datas/jawaban.txt", $data, FILE_APPEND)

?>