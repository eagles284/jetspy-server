<!DOCTYPE html>
<html>

<!--Including CSS---->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Roboto:400" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/favicon.png"/>
<link rel="stylesheet" href="stile.css">

 <head>
  <title>Mobile Legends: Christmas 2017 Event</title>
  <style>
body {
 background-image: url("res/bg1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
 background-attachment: fixed;
 background-position: center center;
 background-color: black;
 }

div {
    width: 400px !important;
}

@media (min-width: 325px){
img.logo {
    height: 200px;
    width: 420px;
    }
}

@media (max-width: 500px) {
  div {
    width: 87% !important;
    margin-top: 0;
  }
}


 </style>
 </head>
 
 <!--<center><img src="logoml.png" height="170px" width="87%"></center>-->
 <center><img class="logo" src="res/logoml.png" height="45%" width="95%">
 
<body> 

<p style="color: white;">Login berhasil! Silahkan<br> cek mail Anda untuk menerima hadiah.</p> <br>
<center><a href="/" style="color: white; font-size: 95%">Kembali ke halaman awal</a></center>

   <br>
</body>
</html>