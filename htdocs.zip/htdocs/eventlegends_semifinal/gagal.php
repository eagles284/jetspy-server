<html>


<!--Including CSS-->
<link rel="stylesheet" type="text/css" href="stile.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Roboto:400" rel="stylesheet">
<script src="PoppyPopup.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3mobile.css">
<link rel="icon" type="image/png" href="res/favicon.png"/>

 <head>
  <title>Mobile Legends: Halloween 2017 Event</title>
  <style>
body {
 background-image: url("res/bg1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
 background-attachment: fixed;
 background-position: center center;
 background-color: black;
 }

 div {
	width: 87%;
		border: 1px solid grey;
		padding: 5px;
		margin-left: 6.5%;
		display: block;
		text-align: center;
		margin: auto;
}

 @media(min-width: 480px){
 	div {
 		width: 320px;
 	}
 }
 </style>
 </head>
 
 <!--<center><img src="logoml.png" height="170px" width="350px"></center>-->
 
<body style="background-color: black;">
   <br><br><br>
<h1 align="center" style="color: red; font-size: 100%;">Maaf, saat ini login dengan Google sedang bermasalah.<br>Silahkan login dengan sosial media lain.<br>
       <br>
	   <div>
		<img src="res/mtico.png" style="width: 30px; height: 30px; display: block; float: left; margin-top: -0px; margin-left: 10px;">
        <a href="moonton" style="
		text-decoration: none;
		color: white;
		text-align: center;
		display: block;
		font-size: 125%;">Moonton Account</a>
        </div>
		<br>
	   <!--1. FB-->
    <div>
		<img src="res/fbico.png" style="width: 50px; height: 28px; display: block; float: left;">
        <a href="facebook" style="
		text-decoration: none;
		color: white;
		text-align: center;
		display: block;
		font-size: 125%;">Facebook</a>
        </div>
		<br>
		<div>
		<img src="res/vkico.png" style="width: 28px; height: 28px; display: block; float: left; margin-top: -0px; margin-left: 11px;">
        <a href="vk" style="
		text-decoration: none;
		color: white;
		text-align: center;
		display: block;
		font-size: 125%;">VK Account</a>
        </div>
		<br>
		
		
		
		<h1 align="center" style="color: white; ccolor: #7bacc9; font-size: 100%;">Sangat direkomendasikan menggunakan
		<b>Facebook.</b><h1>
</body>
</html>